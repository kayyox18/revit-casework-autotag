@echo off
rem Installs the Revit Casework AutoTag add-in for this Windows user (Revit 2022 / 2023 / 2024, whichever are installed).
rem It also removes Windows' "downloaded from the internet" mark from the DLL. With that mark Revit refuses the DLL:
rem "An attempt was made to load an assembly from a network location ... loadFromRemoteSources".
setlocal
cd /d "%~dp0"
if not exist "RevitCaseworkAutoTag.dll" goto missing
if not exist "RevitCaseworkAutoTag.addin" goto missing
set "DONE="
for %%Y in (2022 2023 2024) do if exist "%ProgramFiles%\Autodesk\Revit %%Y\Revit.exe" call :install %%Y
if not defined DONE (
  echo No Revit 2022, 2023 or 2024 found on this PC - nothing installed.
  echo Revit 2025 and newer are not supported by this version.
  pause
  exit /b 1
)
echo.
echo Done. Open Revit. If Revit asks about the add-in "Revit Casework AutoTag", click "Always Load".
echo The commands are in the Add-Ins tab ^> External Tools.
pause
exit /b 0

:install
set "DEST=%APPDATA%\Autodesk\Revit\Addins\%1"
if not exist "%DEST%\RevitCaseworkAutoTag" mkdir "%DEST%\RevitCaseworkAutoTag"
copy /y "RevitCaseworkAutoTag.dll" "%DEST%\RevitCaseworkAutoTag\RevitCaseworkAutoTag.dll" >nul || goto locked
copy /y "RevitCaseworkAutoTag.addin" "%DEST%\RevitCaseworkAutoTag.addin" >nul
powershell -NoProfile -Command "Unblock-File -LiteralPath \"%DEST%\RevitCaseworkAutoTag\RevitCaseworkAutoTag.dll\", \"%DEST%\RevitCaseworkAutoTag.addin\""
dir /r "%DEST%\RevitCaseworkAutoTag\RevitCaseworkAutoTag.dll" | find "Zone.Identifier" >nul && (
  echo Revit %1: installed, but Windows still blocks the DLL. Right-click
  echo   %DEST%\RevitCaseworkAutoTag\RevitCaseworkAutoTag.dll ^> Properties ^> tick Unblock ^> OK.
) || echo Installed for Revit %1
set "DONE=1"
exit /b 0

:locked
echo Revit %1: could not copy the DLL - close Revit and run Install.cmd again.
exit /b 1

:missing
echo RevitCaseworkAutoTag.dll and RevitCaseworkAutoTag.addin must be next to Install.cmd. Unzip the download first.
pause
exit /b 1
